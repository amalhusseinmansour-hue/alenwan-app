INSERT INTO sliders (title, description, media_type, video_type, video_url, is_active, `order`, created_at, updated_at)
VALUES ('New Vimeo Video', 'Added via Request', 'video', 'vimeo', 'https://vimeo.com/1110521673?share=copy&fl=sv&fe=ci', 1, 0, NOW(), NOW());
